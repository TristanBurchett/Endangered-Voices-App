package androidx.core.content;

import androidx.core.util.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IntentSanitizer$$ExternalSyntheticLambda0 implements Consumer {
    public final void accept(Object obj) {
        IntentSanitizer.lambda$sanitizeByFiltering$0((String) obj);
    }
}
