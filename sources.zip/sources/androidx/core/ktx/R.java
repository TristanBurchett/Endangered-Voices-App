package androidx.core.ktx;

public final class R {
    private R() {
    }
}
