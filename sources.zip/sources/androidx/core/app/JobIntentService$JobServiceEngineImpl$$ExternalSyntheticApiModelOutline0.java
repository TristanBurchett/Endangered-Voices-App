package androidx.core.app;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class JobIntentService$JobServiceEngineImpl$$ExternalSyntheticApiModelOutline0 {
}
