package androidx.core.location;

import androidx.core.location.LocationManagerCompat;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LocationManagerCompat$CancellableLocationListener$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ LocationManagerCompat.CancellableLocationListener f$0;

    public /* synthetic */ LocationManagerCompat$CancellableLocationListener$$ExternalSyntheticLambda0(LocationManagerCompat.CancellableLocationListener cancellableLocationListener) {
        this.f$0 = cancellableLocationListener;
    }

    public final void run() {
        this.f$0.m8lambda$startTimeout$0$androidxcorelocationLocationManagerCompat$CancellableLocationListener();
    }
}
