package androidx.asynclayoutinflater;

public final class R {

    public static final class attr {
        public static int alpha = 2130903085;
        public static int font = 2130903470;
        public static int fontProviderAuthority = 2130903472;
        public static int fontProviderCerts = 2130903473;
        public static int fontProviderFetchStrategy = 2130903474;
        public static int fontProviderFetchTimeout = 2130903475;
        public static int fontProviderPackage = 2130903476;
        public static int fontProviderQuery = 2130903477;
        public static int fontStyle = 2130903479;
        public static int fontVariationSettings = 2130903480;
        public static int fontWeight = 2130903481;
        public static int ttcIndex = 2130904097;

        private attr() {
        }
    }

    public static final class color {
        public static int notification_action_color_filter = 2131034695;
        public static int notification_icon_bg_color = 2131034696;
        public static int ripple_material_light = 2131034708;
        public static int secondary_text_default_material_light = 2131034710;

        private color() {
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 2131099736;
        public static int compat_button_inset_vertical_material = 2131099737;
        public static int compat_button_padding_horizontal_material = 2131099738;
        public static int compat_button_padding_vertical_material = 2131099739;
        public static int compat_control_corner_material = 2131099740;
        public static int compat_notification_large_icon_max_height = 2131099741;
        public static int compat_notification_large_icon_max_width = 2131099742;
        public static int notification_action_icon_size = 2131100201;
        public static int notification_action_text_size = 2131100202;
        public static int notification_big_circle_margin = 2131100203;
        public static int notification_content_margin_start = 2131100204;
        public static int notification_large_icon_height = 2131100205;
        public static int notification_large_icon_width = 2131100206;
        public static int notification_main_column_padding_top = 2131100207;
        public static int notification_media_narrow_margin = 2131100208;
        public static int notification_right_icon_size = 2131100209;
        public static int notification_right_side_padding_top = 2131100210;
        public static int notification_small_icon_background_padding = 2131100211;
        public static int notification_small_icon_size_as_large = 2131100212;
        public static int notification_subtext_size = 2131100213;
        public static int notification_top_pad = 2131100214;
        public static int notification_top_pad_large_text = 2131100215;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int notification_action_background = 2131165377;
        public static int notification_bg = 2131165378;
        public static int notification_bg_low = 2131165379;
        public static int notification_bg_low_normal = 2131165380;
        public static int notification_bg_low_pressed = 2131165381;
        public static int notification_bg_normal = 2131165382;
        public static int notification_bg_normal_pressed = 2131165383;
        public static int notification_icon_background = 2131165384;
        public static int notification_template_icon_bg = 2131165386;
        public static int notification_template_icon_low_bg = 2131165387;
        public static int notification_tile_bg = 2131165388;
        public static int notify_panel_notification_icon_bg = 2131165389;

        private drawable() {
        }
    }

    public static final class id {
        public static int action_container = 2131230786;
        public static int action_divider = 2131230788;
        public static int action_image = 2131230789;
        public static int action_text = 2131230795;
        public static int actions = 2131230796;
        public static int async = 2131230809;
        public static int blocking = 2131230823;
        public static int chronometer = 2131230844;
        public static int forever = 2131230930;
        public static int icon = 2131230949;
        public static int icon_group = 2131230950;
        public static int info = 2131230956;
        public static int italic = 2131230960;
        public static int line1 = 2131230970;
        public static int line3 = 2131230971;
        public static int normal = 2131231042;
        public static int notification_background = 2131231043;
        public static int notification_main_column = 2131231044;
        public static int notification_main_column_container = 2131231045;
        public static int right_icon = 2131231076;
        public static int right_side = 2131231077;
        public static int tag_transition_group = 2131231157;
        public static int tag_unhandled_key_event_manager = 2131231158;
        public static int tag_unhandled_key_listeners = 2131231159;
        public static int text = 2131231165;
        public static int text2 = 2131231166;
        public static int time = 2131231182;
        public static int title = 2131231183;

        private id() {
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 2131296310;

        private integer() {
        }
    }

    public static final class layout {
        public static int notification_action = 2131427426;
        public static int notification_action_tombstone = 2131427427;
        public static int notification_template_custom_big = 2131427434;
        public static int notification_template_icon_group = 2131427435;
        public static int notification_template_part_chronometer = 2131427439;
        public static int notification_template_part_time = 2131427440;

        private layout() {
        }
    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 2131689681;

        private string() {
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 2131755453;
        public static int TextAppearance_Compat_Notification_Info = 2131755454;
        public static int TextAppearance_Compat_Notification_Line2 = 2131755456;
        public static int TextAppearance_Compat_Notification_Time = 2131755459;
        public static int TextAppearance_Compat_Notification_Title = 2131755461;
        public static int Widget_Compat_NotificationActionContainer = 2131755823;
        public static int Widget_Compat_NotificationActionText = 2131755824;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] ColorStateListItem = {16843173, 16843551, 16844359, com.gmail.kaiandtristan.myproject.R.attr.alpha, com.gmail.kaiandtristan.myproject.R.attr.lStar};
        public static int ColorStateListItem_alpha = 3;
        public static int ColorStateListItem_android_alpha = 1;
        public static int ColorStateListItem_android_color = 0;
        public static int ColorStateListItem_android_lStar = 2;
        public static int ColorStateListItem_lStar = 4;
        public static int[] FontFamily = {com.gmail.kaiandtristan.myproject.R.attr.fontProviderAuthority, com.gmail.kaiandtristan.myproject.R.attr.fontProviderCerts, com.gmail.kaiandtristan.myproject.R.attr.fontProviderFetchStrategy, com.gmail.kaiandtristan.myproject.R.attr.fontProviderFetchTimeout, com.gmail.kaiandtristan.myproject.R.attr.fontProviderPackage, com.gmail.kaiandtristan.myproject.R.attr.fontProviderQuery, com.gmail.kaiandtristan.myproject.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.gmail.kaiandtristan.myproject.R.attr.font, com.gmail.kaiandtristan.myproject.R.attr.fontStyle, com.gmail.kaiandtristan.myproject.R.attr.fontVariationSettings, com.gmail.kaiandtristan.myproject.R.attr.fontWeight, com.gmail.kaiandtristan.myproject.R.attr.ttcIndex};
        public static int FontFamilyFont_android_font = 0;
        public static int FontFamilyFont_android_fontStyle = 2;
        public static int FontFamilyFont_android_fontVariationSettings = 4;
        public static int FontFamilyFont_android_fontWeight = 1;
        public static int FontFamilyFont_android_ttcIndex = 3;
        public static int FontFamilyFont_font = 5;
        public static int FontFamilyFont_fontStyle = 6;
        public static int FontFamilyFont_fontVariationSettings = 7;
        public static int FontFamilyFont_fontWeight = 8;
        public static int FontFamilyFont_ttcIndex = 9;
        public static int FontFamily_fontProviderAuthority = 0;
        public static int FontFamily_fontProviderCerts = 1;
        public static int FontFamily_fontProviderFetchStrategy = 2;
        public static int FontFamily_fontProviderFetchTimeout = 3;
        public static int FontFamily_fontProviderPackage = 4;
        public static int FontFamily_fontProviderQuery = 5;
        public static int FontFamily_fontProviderSystemFontFamily = 6;
        public static int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static int[] GradientColorItem = {16843173, 16844052};
        public static int GradientColorItem_android_color = 0;
        public static int GradientColorItem_android_offset = 1;
        public static int GradientColor_android_centerColor = 7;
        public static int GradientColor_android_centerX = 3;
        public static int GradientColor_android_centerY = 4;
        public static int GradientColor_android_endColor = 1;
        public static int GradientColor_android_endX = 10;
        public static int GradientColor_android_endY = 11;
        public static int GradientColor_android_gradientRadius = 5;
        public static int GradientColor_android_startColor = 0;
        public static int GradientColor_android_startX = 8;
        public static int GradientColor_android_startY = 9;
        public static int GradientColor_android_tileMode = 6;
        public static int GradientColor_android_type = 2;

        private styleable() {
        }
    }

    private R() {
    }
}
