package androidx.coordinatorlayout;

public final class R {

    public static final class attr {
        public static int coordinatorLayoutStyle = 2130903310;
        public static int keylines = 2130903565;
        public static int layout_anchor = 2130903576;
        public static int layout_anchorGravity = 2130903577;
        public static int layout_behavior = 2130903578;
        public static int layout_dodgeInsetEdges = 2130903623;
        public static int layout_insetEdge = 2130903632;
        public static int layout_keyline = 2130903633;
        public static int statusBarBackground = 2130903926;

        private attr() {
        }
    }

    public static final class id {
        public static int bottom = 2131230824;
        public static int end = 2131230907;
        public static int left = 2131230967;
        public static int none = 2131231041;
        public static int right = 2131231074;
        public static int start = 2131231136;
        public static int top = 2131231187;

        private id() {
        }
    }

    public static final class style {
        public static int Widget_Support_CoordinatorLayout = 2131756097;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] CoordinatorLayout = {com.gmail.kaiandtristan.myproject.R.attr.keylines, com.gmail.kaiandtristan.myproject.R.attr.statusBarBackground};
        public static int[] CoordinatorLayout_Layout = {16842931, com.gmail.kaiandtristan.myproject.R.attr.layout_anchor, com.gmail.kaiandtristan.myproject.R.attr.layout_anchorGravity, com.gmail.kaiandtristan.myproject.R.attr.layout_behavior, com.gmail.kaiandtristan.myproject.R.attr.layout_dodgeInsetEdges, com.gmail.kaiandtristan.myproject.R.attr.layout_insetEdge, com.gmail.kaiandtristan.myproject.R.attr.layout_keyline};
        public static int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static int CoordinatorLayout_Layout_layout_anchor = 1;
        public static int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static int CoordinatorLayout_Layout_layout_behavior = 3;
        public static int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static int CoordinatorLayout_Layout_layout_keyline = 6;
        public static int CoordinatorLayout_keylines = 0;
        public static int CoordinatorLayout_statusBarBackground = 1;

        private styleable() {
        }
    }

    private R() {
    }
}
