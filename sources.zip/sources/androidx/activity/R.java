package androidx.activity;

public final class R {

    public static final class id {
        public static int view_tree_on_back_pressed_dispatcher_owner = 2131231209;

        private id() {
        }
    }

    private R() {
    }
}
