package androidx.activity;

import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ComponentActivity$$ExternalSyntheticLambda1 implements SavedStateRegistry.SavedStateProvider {
    public final /* synthetic */ ComponentActivity f$0;

    public /* synthetic */ ComponentActivity$$ExternalSyntheticLambda1(ComponentActivity componentActivity) {
        this.f$0 = componentActivity;
    }

    public final Bundle saveState() {
        return this.f$0.m0lambda$new$0$androidxactivityComponentActivity();
    }
}
