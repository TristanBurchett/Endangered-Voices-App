package androidx.activity.contextaware;

import android.content.Context;

public interface OnContextAvailableListener {
    void onContextAvailable(Context context);
}
