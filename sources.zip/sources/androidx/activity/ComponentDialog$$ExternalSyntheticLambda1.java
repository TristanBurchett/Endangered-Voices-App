package androidx.activity;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ComponentDialog$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ ComponentDialog f$0;

    public /* synthetic */ ComponentDialog$$ExternalSyntheticLambda1(ComponentDialog componentDialog) {
        this.f$0 = componentDialog;
    }

    public final void run() {
        ComponentDialog.m2onBackPressedDispatcher$lambda1(this.f$0);
    }
}
