package androidx.activity.result;

public interface ActivityResultRegistryOwner {
    ActivityResultRegistry getActivityResultRegistry();
}
