package androidx.activity;

import androidx.core.util.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class OnBackPressedDispatcher$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ OnBackPressedDispatcher f$0;

    public /* synthetic */ OnBackPressedDispatcher$$ExternalSyntheticLambda0(OnBackPressedDispatcher onBackPressedDispatcher) {
        this.f$0 = onBackPressedDispatcher;
    }

    public final void accept(Object obj) {
        this.f$0.m3lambda$new$0$androidxactivityOnBackPressedDispatcher((Boolean) obj);
    }
}
