package androidx.appcompat.app;

import androidx.appcompat.app.AppLocalesStorageHelper;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AppLocalesStorageHelper$SerialExecutor$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ AppLocalesStorageHelper.SerialExecutor f$0;
    public final /* synthetic */ Runnable f$1;

    public /* synthetic */ AppLocalesStorageHelper$SerialExecutor$$ExternalSyntheticLambda0(AppLocalesStorageHelper.SerialExecutor serialExecutor, Runnable runnable) {
        this.f$0 = serialExecutor;
        this.f$1 = runnable;
    }

    public final void run() {
        this.f$0.m4lambda$execute$0$androidxappcompatappAppLocalesStorageHelper$SerialExecutor(this.f$1);
    }
}
