package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AppCompatDelegateImpl$Api33Impl$$ExternalSyntheticLambda5 implements OnBackInvokedCallback {
    public final /* synthetic */ AppCompatDelegateImpl f$0;

    public /* synthetic */ AppCompatDelegateImpl$Api33Impl$$ExternalSyntheticLambda5(AppCompatDelegateImpl appCompatDelegateImpl) {
        this.f$0 = appCompatDelegateImpl;
    }

    public final void onBackInvoked() {
        this.f$0.onBackPressed();
    }
}
