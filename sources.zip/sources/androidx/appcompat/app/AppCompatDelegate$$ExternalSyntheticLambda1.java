package androidx.appcompat.app;

import android.content.Context;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AppCompatDelegate$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ Context f$0;

    public /* synthetic */ AppCompatDelegate$$ExternalSyntheticLambda1(Context context) {
        this.f$0 = context;
    }

    public final void run() {
        AppCompatDelegate.lambda$syncRequestedAndStoredLocales$1(this.f$0);
    }
}
