package androidx.appcompat.widget;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Toolbar$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ Toolbar f$0;

    public /* synthetic */ Toolbar$$ExternalSyntheticLambda1(Toolbar toolbar) {
        this.f$0 = toolbar;
    }

    public final void run() {
        this.f$0.collapseActionView();
    }
}
