package androidx.appcompat.widget;

public interface EmojiCompatConfigurationView {
    boolean isEmojiCompatEnabled();

    void setEmojiCompatEnabled(boolean z);
}
