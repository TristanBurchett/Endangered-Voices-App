package androidx.appcompat.widget;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Toolbar$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Toolbar f$0;

    public /* synthetic */ Toolbar$$ExternalSyntheticLambda0(Toolbar toolbar) {
        this.f$0 = toolbar;
    }

    public final void run() {
        this.f$0.invalidateMenu();
    }
}
