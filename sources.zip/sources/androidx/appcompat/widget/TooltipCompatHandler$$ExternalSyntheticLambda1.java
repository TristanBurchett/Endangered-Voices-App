package androidx.appcompat.widget;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class TooltipCompatHandler$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ TooltipCompatHandler f$0;

    public /* synthetic */ TooltipCompatHandler$$ExternalSyntheticLambda1(TooltipCompatHandler tooltipCompatHandler) {
        this.f$0 = tooltipCompatHandler;
    }

    public final void run() {
        this.f$0.hide();
    }
}
