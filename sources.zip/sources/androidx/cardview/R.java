package androidx.cardview;

public final class R {

    public static final class attr {
        public static int cardBackgroundColor = 2130903174;
        public static int cardCornerRadius = 2130903175;
        public static int cardElevation = 2130903176;
        public static int cardMaxElevation = 2130903178;
        public static int cardPreventCornerOverlap = 2130903179;
        public static int cardUseCompatPadding = 2130903180;
        public static int cardViewStyle = 2130903181;
        public static int contentPadding = 2130903300;
        public static int contentPaddingBottom = 2130903301;
        public static int contentPaddingLeft = 2130903303;
        public static int contentPaddingRight = 2130903304;
        public static int contentPaddingTop = 2130903306;

        private attr() {
        }
    }

    public static final class color {
        public static int cardview_dark_background = 2131034155;
        public static int cardview_light_background = 2131034156;
        public static int cardview_shadow_end_color = 2131034157;
        public static int cardview_shadow_start_color = 2131034158;

        private color() {
        }
    }

    public static final class dimen {
        public static int cardview_compat_inset_shadow = 2131099732;
        public static int cardview_default_elevation = 2131099733;
        public static int cardview_default_radius = 2131099734;

        private dimen() {
        }
    }

    public static final class style {
        public static int Base_CardView = 2131755024;
        public static int CardView = 2131755282;
        public static int CardView_Dark = 2131755283;
        public static int CardView_Light = 2131755284;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] CardView = {16843071, 16843072, com.gmail.kaiandtristan.myproject.R.attr.cardBackgroundColor, com.gmail.kaiandtristan.myproject.R.attr.cardCornerRadius, com.gmail.kaiandtristan.myproject.R.attr.cardElevation, com.gmail.kaiandtristan.myproject.R.attr.cardMaxElevation, com.gmail.kaiandtristan.myproject.R.attr.cardPreventCornerOverlap, com.gmail.kaiandtristan.myproject.R.attr.cardUseCompatPadding, com.gmail.kaiandtristan.myproject.R.attr.contentPadding, com.gmail.kaiandtristan.myproject.R.attr.contentPaddingBottom, com.gmail.kaiandtristan.myproject.R.attr.contentPaddingLeft, com.gmail.kaiandtristan.myproject.R.attr.contentPaddingRight, com.gmail.kaiandtristan.myproject.R.attr.contentPaddingTop};
        public static int CardView_android_minHeight = 1;
        public static int CardView_android_minWidth = 0;
        public static int CardView_cardBackgroundColor = 2;
        public static int CardView_cardCornerRadius = 3;
        public static int CardView_cardElevation = 4;
        public static int CardView_cardMaxElevation = 5;
        public static int CardView_cardPreventCornerOverlap = 6;
        public static int CardView_cardUseCompatPadding = 7;
        public static int CardView_contentPadding = 8;
        public static int CardView_contentPaddingBottom = 9;
        public static int CardView_contentPaddingLeft = 10;
        public static int CardView_contentPaddingRight = 11;
        public static int CardView_contentPaddingTop = 12;

        private styleable() {
        }
    }

    private R() {
    }
}
