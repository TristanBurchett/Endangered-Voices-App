package android.location;

public /* synthetic */ class GnssMeasurementsEvent$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
