package android.location;

public /* synthetic */ class GnssStatus$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
