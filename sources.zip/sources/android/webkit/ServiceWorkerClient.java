package android.webkit;

public /* synthetic */ class ServiceWorkerClient {
    static {
        throw new NoClassDefFoundError();
    }
}
