package android.webkit;

public /* synthetic */ class WebViewRenderProcessClient {
    static {
        throw new NoClassDefFoundError();
    }
}
