package android.os;

public /* synthetic */ interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}
