package android.app;

public /* synthetic */ class AppComponentFactory {
    static {
        throw new NoClassDefFoundError();
    }
}
