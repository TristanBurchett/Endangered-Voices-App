package android.app.job;

public /* synthetic */ class JobServiceEngine {
    static {
        throw new NoClassDefFoundError();
    }
}
