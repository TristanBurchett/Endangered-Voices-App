package android.graphics;

public /* synthetic */ interface ImageDecoder$OnHeaderDecodedListener {
    static {
        throw new NoClassDefFoundError();
    }
}
