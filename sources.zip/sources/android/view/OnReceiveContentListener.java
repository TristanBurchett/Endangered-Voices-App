package android.view;

public /* synthetic */ interface OnReceiveContentListener {
    static {
        throw new NoClassDefFoundError();
    }
}
