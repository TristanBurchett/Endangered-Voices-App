package android.view;

public /* synthetic */ interface Window$OnFrameMetricsAvailableListener {
    static {
        throw new NoClassDefFoundError();
    }
}
