package android.view;

public /* synthetic */ class WindowInsetsAnimation$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
