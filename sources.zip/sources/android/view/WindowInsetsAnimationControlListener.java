package android.view;

public /* synthetic */ interface WindowInsetsAnimationControlListener {
    static {
        throw new NoClassDefFoundError();
    }
}
